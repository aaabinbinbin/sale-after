# Agent 与 RAG 模块完整设计

---

## 1. Agent 在本项目中的定位

本项目的 Agent 不是一个泛聊天机器人，也不是为了炫技强行多 Agent。它的定位是：

```text
面向电商售后业务的智能入口 + 客服辅助决策器 + 业务工具编排器
```

Agent 要做的是：

- 理解用户自然语言售后诉求。
- 把自然语言转成结构化意图。
- 查询订单事实。
- 判断售后资格。
- 检索售后政策和历史案例。
- 生成售后申请草稿。
- 生成客服处理建议。
- 对高风险动作生成待确认动作。
- 记录完整 trace。

Agent 不应该做的是：

- 编造订单事实。
- 绕过业务服务直接查数据库。
- 绕过权限执行退款。
- 无确认审核通过。
- 每次请求都强制 RAG。
- 每次请求都走固定流程。
- 为了多 Agent 而多 Agent。

---

## 2. 为什么 Agent 不能设计成线性流程

之前讨论过一个关键点：如果售后业务本身是线性的，强行多 Agent 或固定流程会增加调用开销，不一定有价值。

错误设计：

```text
用户输入
    ↓
意图识别
    ↓
RAG
    ↓
工具调用
    ↓
总结
    ↓
执行
```

这个设计的问题：

1. 普通进度查询不需要 RAG。
2. 政策问答不需要订单工具。
3. 创建售后申请需要订单查询和资格判断，但不一定需要复杂 RAG。
4. 高风险动作不能直接执行。
5. 每次固定调用会浪费 token 和时间。
6. Debug 困难。
7. 面试时会被问“为什么每次都要走这么多步骤”。

正确设计：

```text
用户输入
    ↓
上下文构建
    ↓
意图识别
    ↓
根据意图选择能力
        ├── 政策问答 → RAG
        ├── 订单资格判断 → 订单工具 + 资格工具
        ├── 创建申请 → 订单工具 + 资格工具 + 草稿生成 + 确认态
        ├── 查询进度 → 售后查询工具
        ├── 客服辅助 → 订单 + 售后详情 + RAG + 建议
        └── 未知意图 → 澄清问题
    ↓
风险评估
    ↓
确认或回答
    ↓
Trace
```

---

## 3. Agent 架构

```text
AgentController
    ↓
AgentFacade
    ↓
AgentContextBuilder
    ↓
AgentIntentRouter
    ↓
AgentPlanner
    ↓
SkillRegistry
    ↓
AgentSkill
    ├── OrderQuerySkill
    ├── AfterSalesEligibilitySkill
    ├── AfterSalesDraftSkill
    ├── AfterSalesCreateSkill
    ├── AfterSalesProgressSkill
    ├── RefundEstimateSkill
    ├── ExchangeStockCheckSkill
    ├── CompensationSuggestionSkill
    └── RagRetrieveSkill
    ↓
AgentRiskGuard
    ↓
AgentConfirmService
    ↓
AgentTraceService
```

---

## 4. AgentController

接口：

```http
POST /api/agent/chat
POST /api/agent/chat/stream
POST /api/agent/confirm
GET  /api/agent/traces/{traceId}
GET  /api/agent/traces/recent
```

Controller 只负责接收请求、参数校验、获取当前用户、调用 AgentFacade、返回响应或 SSE。不要在 Controller 中写意图识别和工具调用。

---

## 5. AgentFacade

AgentFacade 是 Agent 主入口。

职责：

1. 创建 traceId。
2. 记录用户输入。
3. 构建上下文。
4. 调用意图识别。
5. 调用 Planner。
6. 通过 SkillRegistry 执行技能。
7. 调用 RiskGuard 判断风险。
8. 需要确认则创建 confirmToken。
9. 不需要确认则生成最终回答。
10. 记录 trace 和 tool call。
11. 返回结果。

伪流程：

```text
createTrace
buildContext
routeIntent
buildPlan
executeSkills
checkRisk
buildConfirmOrAnswer
saveTrace
return
```

---

## 6. AgentContextBuilder

上下文不是越多越好。应该按需构建。

基础上下文：

- userId
- role
- conversationId
- userInput
- orderNo
- afterSalesNo
- currentTime

业务上下文：

- 当前订单摘要
- 当前售后摘要
- 用户最近售后历史
- 客服权限
- 可用技能列表

对话上下文：

- 最近几轮会话
- 会话摘要
- 上一次 confirm 状态

注意：

- 不要把完整订单、完整日志、完整知识库全部塞进 prompt。
- 工具能查的事实，让工具查。
- RAG 能检索的知识，让 RAG 检索。
- Prompt 只放必要摘要。

---

## 7. AgentIntentRouter

意图类型：

```text
AFTER_SALES_POLICY_QA
ORDER_AFTER_SALES_ELIGIBILITY
CREATE_AFTER_SALES_APPLICATION
QUERY_AFTER_SALES_PROGRESS
SUPPLEMENT_AFTER_SALES_PROOF
CUSTOMER_SERVICE_ASSISTANT
COMPLAINT_ANALYSIS
REFUND_ESTIMATION
EXCHANGE_STOCK_CHECK
UNKNOWN
```

输出结构：

```json
{
  "intent": "CREATE_AFTER_SALES_APPLICATION",
  "confidence": 0.86,
  "entities": {
    "orderNo": "O202605100001",
    "afterSalesType": "RETURN_REFUND",
    "reason": "商品质量问题"
  },
  "needRag": true,
  "needTool": true
}
```

实现方式：

- 规则兜底。
- LLM 分类。
- 低置信度时返回澄清问题。
- 不要让 LLM 直接输出业务动作并执行。

---

## 8. AgentPlanner

Planner 的作用不是炫技，而是让执行过程可解释、可追踪、可恢复。

示例：

```json
{
  "planId": "plan-xxx",
  "intent": "CREATE_AFTER_SALES_APPLICATION",
  "steps": [
    {
      "stepNo": 1,
      "skill": "order.query",
      "name": "查询订单信息",
      "required": true
    },
    {
      "stepNo": 2,
      "skill": "after_sales.eligibility.check",
      "name": "判断售后资格",
      "required": true
    },
    {
      "stepNo": 3,
      "skill": "rag.retrieve",
      "name": "检索售后政策",
      "required": false
    },
    {
      "stepNo": 4,
      "skill": "after_sales.application.draft",
      "name": "生成售后申请草稿",
      "required": true
    }
  ],
  "status": "WAIT_CONFIRM"
}
```

Planner 不要把所有请求都规划成同样步骤。

---

## 9. SkillRegistry

SkillRegistry 统一管理能力。

注册示例：

```text
order.query
after_sales.eligibility.check
after_sales.application.draft
after_sales.application.create
after_sales.progress.query
refund.estimate
exchange.stock.check
compensation.suggest
rag.retrieve
policy.qa
```

### 9.1 为什么需要 SkillRegistry

如果 AgentFacade 直接依赖十几个 Tool，会导致构造函数很乱、新增工具要改主流程、测试困难、能力边界不清晰。SkillRegistry 让 AgentFacade 只面向统一接口。

---

## 10. AgentSkill 接口设计

```java
/**
 * Agent 技能接口。
 *
 * 每个技能代表一个可被 Agent 调用的业务能力。技能内部只能调用业务 Service，
 * 不能直接操作 Mapper，也不能绕过权限和状态机执行高风险动作。
 */
public interface AgentSkill {

    /**
     * 返回技能名称。
     */
    String name();

    /**
     * 判断当前上下文是否支持执行该技能。
     */
    boolean supports(AgentContext context, AgentPlanStep step);

    /**
     * 执行技能。
     */
    AgentSkillResult execute(AgentContext context, AgentPlanStep step);
}
```

---

## 11. 核心 Skills

### 11.1 OrderQuerySkill

用途：查询订单事实、查询订单项、查询支付记录、给后续售后资格判断提供数据。

不能做：修改订单、创建售后、推断不存在的订单。

### 11.2 AfterSalesEligibilitySkill

用途：判断订单是否允许售后、判断订单项是否允许售后、判断数量和金额是否合法、返回失败原因。

复用业务服务：`AfterSalesEligibilityService`。

### 11.3 AfterSalesDraftSkill

用途：生成售后申请草稿，把用户自然语言诉求转成结构化申请，不创建真实售后单。

输出：

```json
{
  "afterSalesType": "RETURN_REFUND",
  "reasonCode": "QUALITY_PROBLEM",
  "reasonText": "耳机左耳无声",
  "items": [
    {
      "orderItemId": 10001,
      "applyQuantity": 1
    }
  ]
}
```

### 11.4 AfterSalesCreateSkill

用途：创建真实售后单。

注意：属于高风险动作，不能直接执行，必须通过 confirm。

### 11.5 RagRetrieveSkill

用途：检索政策、FAQ、历史案例，返回命中文档摘要。

注意：只在需要知识支撑时调用，普通进度查询不调用。

### 11.6 RefundEstimateSkill

用途：预估退款金额，解释退款组成。

注意：只是预估，不执行退款。

### 11.7 ExchangeStockCheckSkill

用途：检查换货 SKU 库存，判断是否可以换货。

注意：检查不等于锁定，锁定库存是高风险业务动作。

---

## 12. 风险控制 AgentRiskGuard

风险等级：

```text
LOW       普通问答、政策解释、进度查询
MEDIUM    售后草稿、退款预估、库存检查
HIGH      创建售后、审核通过、退款、补偿、换货发货
```

高风险动作：

- CREATE_AFTER_SALES_APPLICATION
- APPROVE_AFTER_SALES
- EXECUTE_REFUND
- GRANT_COMPENSATION
- SHIP_EXCHANGE
- CONFIRM_RETURN_RECEIVED

高风险处理：

```text
识别高风险动作
    ↓
不直接执行
    ↓
生成 confirmToken
    ↓
保存待确认动作
    ↓
返回前端
    ↓
用户或客服确认
    ↓
confirm 接口执行
```

---

## 13. Agent Confirm

ConfirmToken 内容：

```json
{
  "traceId": "t-xxx",
  "userId": 10001,
  "actionType": "CREATE_AFTER_SALES_APPLICATION",
  "payload": {},
  "expireAt": "2026-05-10T15:30:00"
}
```

存储：

- Redis：快速校验，TTL。
- MySQL：审计记录，可追踪。

Redis Key：

```text
agent:confirm:{confirmToken}
```

确认时必须再次校验：token 存在、未过期、当前用户有权限、action 状态未执行、业务状态仍允许、version 仍匹配、幂等 Key 正确。

---

## 14. SSE 流式输出

SSE 事件设计：

```text
trace       返回 traceId
thought     展示当前阶段
tool        工具调用状态
retrieve    RAG 检索结果
delta       模型文本增量
confirm     高风险确认动作
error       错误事件
done        完成事件
```

示例：

```text
event: trace
data: {"traceId":"t-20260510-0001"}

event: thought
data: {"content":"正在识别你的售后诉求"}

event: tool
data: {"toolName":"OrderQuerySkill","status":"STARTED"}

event: tool
data: {"toolName":"OrderQuerySkill","status":"SUCCESS"}

event: retrieve
data: {"hitCount":3,"topDocs":["7天无理由退货规则","质量问题退货规则"]}

event: delta
data: {"content":"我查到你的订单已签收 3 天，仍在售后期内..."}

event: confirm
data: {"confirmToken":"confirm-xxx","actionType":"CREATE_AFTER_SALES_APPLICATION"}

event: done
data: {"traceId":"t-20260510-0001"}
```

实现注意：traceId 尽早返回，工具调用过程要返回，异常要返回 error，最后必须 done，SSE 断开要记录 trace 状态。

---

## 15. Agent Trace

Trace 记录：traceId、userId、conversationId、userInput、intent、riskLevel、toolCalls、ragHits、finalAnswer、status、error、latency。

为什么要 Trace：Debug Agent、面试展示、高风险动作审计、分析工具失败率、分析 RAG 命中效果。

---

## 16. Prompt 设计

### 16.1 系统 Prompt 原则

Prompt 必须强调：

- 不能编造订单事实。
- 订单事实必须来自工具。
- 售后政策必须来自 RAG 或已配置规则。
- 高风险动作不能直接执行。
- 输出必须结构化。
- 不确定时要澄清。
- 不得绕过权限和状态机。

### 16.2 意图识别 Prompt 输出

```json
{
  "intent": "",
  "confidence": 0.0,
  "entities": {},
  "needTool": true,
  "needRag": false,
  "clarifyQuestion": ""
}
```

### 16.3 客服辅助 Prompt

输入：售后详情摘要、订单摘要、用户诉求、凭证摘要、RAG 命中政策、历史案例。

输出：

```json
{
  "summary": "用户反馈商品破损，已上传图片凭证。",
  "riskPoints": ["金额较高", "历史已有一次售后"],
  "suggestedDecision": "APPROVE",
  "reason": "符合质量问题退货规则",
  "replyToUser": "很抱歉给你带来不便..."
}
```

---

## 17. RAG 定位

RAG 的作用是售后政策解释、FAQ 问答、历史案例参考、客服处理建议、标准话术生成、复杂规则补充。

RAG 不适合查询订单事实、查询售后状态、执行退款、判断实时库存、代替状态机。

---

## 18. RAG 触发时机

### 18.1 需要 RAG

- 用户问售后政策。
- 客服需要处理建议。
- 用户描述复杂投诉。
- Agent 不确定规则。
- 需要引用历史案例。
- 需要生成拒绝/安抚话术。

### 18.2 不需要 RAG

- 用户查售后进度。
- 用户查订单状态。
- 用户补充物流单号。
- 客服执行明确退款动作。
- 系统执行状态机流转。

---

## 19. 知识来源

```text
POLICY    售后政策
FAQ       常见问题
CASE      历史售后案例
MANUAL    客服处理手册
SCRIPT    标准话术
```

### 19.1 历史案例知识格式

```text
标题：耳机左耳无声退货退款案例
背景：用户购买蓝牙耳机，签收 3 天后反馈左耳无声。
订单情况：已支付，已签收，在 7 天售后期内。
用户诉求：退货退款。
凭证：用户上传视频证明左耳无声。
处理过程：客服审核凭证，通过退货退款申请。
结果：用户退货，商家收货后退款。
经验总结：质量问题且凭证清晰时，可按质量问题退货规则处理。
```

---

## 20. 知识构建流程

```text
售后完成
    ↓
AfterSalesCompletedEvent
    ↓
判断是否值得沉淀
    ↓
创建 knowledge_build_task
    ↓
发送 RabbitMQ 消息
    ↓
KnowledgeBuildConsumer 消费
    ↓
读取售后主单、明细、凭证摘要、评论、日志、处理结果
    ↓
生成案例文档
    ↓
保存 knowledge_doc
    ↓
切分 chunk
    ↓
保存 knowledge_chunk
    ↓
调用 EmbeddingModel
    ↓
写入 pgvector
    ↓
更新任务成功
```

---

## 21. 切片策略

政策文档：按章节、条款切，保留标题层级，chunk 控制 300 到 800 中文字，overlap 控制 50 到 100 中文字。

案例文档：按背景、诉求、订单情况、凭证情况、处理过程、处理结果、经验总结组织。每个案例可以一个 chunk，也可以多个 chunk。

---

## 22. pgvector Metadata

metadata 示例：

```json
{
  "docType": "CASE",
  "afterSalesType": "RETURN_REFUND",
  "reasonCode": "QUALITY_PROBLEM",
  "sourceType": "AFTER_SALES_CASE",
  "sourceId": "AS202605100001",
  "status": "ACTIVE"
}
```

metadata 作用：按文档类型过滤、按售后类型过滤、按原因过滤、排除失效知识、支持客服只看政策或案例。

---

## 23. RAG 检索流程

```text
用户问题
    ↓
判断是否需要 RAG
    ↓
Query Rewrite 可选
    ↓
Embedding
    ↓
向量检索 topK
    ↓
metadata 过滤
    ↓
可选 rerank
    ↓
组装上下文
    ↓
LLM 生成回答
    ↓
返回引用来源
```

---

## 24. RAG 评估

必须有评估，否则 RAG 很难证明价值。

指标：Recall@3、Recall@5、MRR。

### 24.1 评估集示例

```json
[
  {
    "question": "签收超过 7 天还能退货退款吗？",
    "expectedDocNos": ["POLICY_RETURN_001"]
  },
  {
    "question": "商品破损但用户没有包装盒怎么办？",
    "expectedDocNos": ["POLICY_PROOF_002", "CASE_DAMAGE_003"]
  }
]
```

### 24.2 Recall@K

```text
如果 expectedDocNos 中任意文档出现在 topK，则该问题命中。
Recall@K = 命中问题数 / 总问题数
```

### 24.3 MRR

```text
MRR = 每个问题第一个相关文档排名倒数的平均值
```

如果第一个相关文档排第 1，RR = 1；排第 3，RR = 1/3；没有命中，RR = 0。

---

## 25. RAG 回退策略

开发环境可以 MySQL fallback。但要明确：fallback 只用于 local/dev，不应作为生产主检索路径，日志必须清楚，面试时要解释这是开发便利，不是最终架构。

日志示例：

```text
RAG vectorStoreReady=false，启用 MySQL fallback。该路径仅用于 local/dev，不应作为长期主检索路径。
```

---

## 26. 多 Agent 取舍

本项目不强行多 Agent。

### 26.1 为什么不强行多 Agent

- 售后大部分流程可由主 Agent + Skills 完成。
- 多 Agent 会增加 token 成本。
- 多 Agent 会增加调用延迟。
- 多 Agent 会增加调试复杂度。
- 面试中容易被问“为什么需要多 Agent”。

### 26.2 什么时候可以拆分

只有当职责非常明确时才拆：EvidenceReviewAgent（凭证审核辅助）、PolicyAgent（政策解释）、CaseSummaryAgent（售后完成后生成案例摘要）、CustomerServiceAssistantAgent（客服侧建议）、MainAfterSaleAgent（主入口）。

但当前更推荐：

```text
一个主 Agent + 多个 Skill
```

这更工程化、更可控。

---

## 27. Agent/RAG 面试解释

可以这样讲：

> 我没有把 Agent 做成固定链路，而是做成一个业务编排入口。用户输入先经过意图识别，然后根据意图按需调用订单查询、售后资格判断、RAG 检索、退款预估、换货库存检查等 Skill。RAG 只在政策问答、复杂规则解释、客服辅助建议等场景触发。涉及创建售后、审核通过、退款、补偿、换货发货等高风险动作时，Agent 只生成待确认动作和 confirmToken，必须由用户或客服确认后才调用业务服务执行。整个过程会记录 traceId、工具调用、RAG 命中和最终回答，便于审计和调试。
