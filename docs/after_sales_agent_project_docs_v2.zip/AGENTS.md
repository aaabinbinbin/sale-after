# AGENTS.md

本文件用于约束 Claude Code、Codex 或其他编码 Agent 在本仓库中的行为。

---

## 1. 项目定位

本项目是电商售后智能 Agent 平台，不是普通 CRUD Demo，也不是纯聊天机器人。核心目标是把真实电商售后业务、Java 后端工程、Agent 工具调用、RAG 知识库和可观测性结合起来。

---

## 2. 固定技术选型

必须使用：

- Java 21
- Spring Boot 3.x
- MyBatis
- MySQL
- Redis
- RabbitMQ
- PostgreSQL + pgvector
- Spring AI
- Vue 3 最后实现

不要改成：

- JPA
- MyBatis-Plus 作为核心 ORM
- MongoDB
- 纯前端 Demo
- 纯 ChatBot Demo

---

## 3. 核心业务约束

1. 一个售后主单只处理一种售后类型。
2. 一次售后多个商品通过 `after_sales_item` 实现。
3. 售后主单不要直接存单个 `order_item_id`。
4. 订单表 `paid_amount` 是订单成交快照。
5. 支付记录表 `pay_amount` 是支付流水金额。
6. 换货短期库存锁定使用 Redis。
7. MySQL 保存最终库存事实。
8. 售后主单必须有 `version` 乐观锁。
9. 补偿记录必须保留 `external_grant_no`。
10. 售后凭证保存 `file_key`，不保存本机绝对路径。
11. 幂等 Key 只从请求头 `Idempotency-Key` 获取。
12. 状态流转必须走状态机。
13. 关键状态变化必须写操作日志。
14. 高风险动作必须确认。

---

## 4. Agent 约束

1. Agent 不是固定线性流程。
2. 不要每次强制 RAG。
3. 不要每次强制所有工具调用。
4. 使用 `SkillRegistry` 管理能力。
5. Skill 调用业务 Service，不直接操作 Mapper。
6. Agent 不得编造订单事实。
7. Agent 不得越权执行业务动作。
8. 退款、补偿、审核通过、换货发货等动作必须生成 confirmToken。
9. Agent 每次调用必须记录 traceId。
10. SSE 事件包括 trace、thought、tool、retrieve、delta、confirm、error、done。

---

## 5. RAG 约束

1. RAG 用于政策、FAQ、历史案例、客服手册。
2. RAG 不替代订单查询和状态机。
3. 售后完成后通过 RabbitMQ 异步构建知识。
4. 知识构建包括文档生成、切片、Embedding、写入 pgvector。
5. 必须实现 Recall@3、Recall@5、MRR。
6. local/dev 可以 MySQL fallback，但日志必须说明不是长期主路径。

---

## 6. 代码规范

1. 类必须有中文 JavaDoc。
2. public 方法必须有中文 JavaDoc。
3. 核心字段必须有中文 `//` 注释。
4. 复杂方法内部必须有中文步骤注释。
5. Controller 不写复杂业务。
6. Service 做用例编排。
7. Domain Service 做业务规则。
8. Mapper 只做数据访问。
9. MyBatis SQL 必须清晰可控。
10. 文档和代码必须保持一致。

---

## 7. 每次修改后输出

每次完成任务后，必须说明：

1. 新增/修改了哪些文件。
2. 实现了哪些能力。
3. 如何运行。
4. 如何测试。
5. 还有哪些未完成。

不要只生成伪代码。不要只写空方法。不要跳过测试。
