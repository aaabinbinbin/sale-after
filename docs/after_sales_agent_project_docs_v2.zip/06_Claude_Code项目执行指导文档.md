# Claude Code 项目执行指导文档

---

## 1. 文档用途

本文档用于直接交给 Claude Code / Claude Code CLI / IDE 编码助手执行。目标是让 Claude Code 按照清晰步骤实现电商售后 Agent 项目，而不是生成零散 Demo。

---

## 2. 总任务

实现项目：

```text
after-sales-agent-platform
```

项目定位：

```text
基于 Java 21 + Spring Boot 3.x + MyBatis + MySQL + Redis + RabbitMQ + PostgreSQL/pgvector + Spring AI 的电商售后智能 Agent 平台。
```

必须覆盖：

- 电商订单基础数据
- 售后申请
- 售后审核
- 退款
- 退货
- 换货
- 补偿
- 售后凭证
- 评论与操作日志
- 幂等
- Redis 锁与库存锁定
- RabbitMQ 异步知识构建
- RAG 知识库
- Agent 意图识别、Skill 调用、确认态、Trace、SSE
- Dashboard
- 测试与文档

---

## 3. 技术约束

必须使用：

```text
Java 21
Spring Boot 3.x
MyBatis
MySQL
Redis
RabbitMQ
PostgreSQL + pgvector
Spring AI
Vue 3 最后实现
```

禁止擅自替换：

```text
JPA
MyBatis-Plus 作为核心 ORM
MongoDB
本地模型强依赖
纯 ChatBot Demo
前端优先
```

---

## 4. 业务硬约束

Claude Code 必须遵守：

1. 一个售后主单只处理一种售后类型。
2. 一次售后多个商品通过 `after_sales_item` 表实现。
3. 售后主单不要直接保存单个 `order_item_id`。
4. 订单表保留 `paid_amount`，支付记录表保留 `pay_amount`。
5. Redis 保存换货短期锁定库存，MySQL 保存最终库存事实。
6. 售后主单必须有 `version` 乐观锁字段。
7. 补偿记录必须有 `external_grant_no`。
8. 售后凭证保存 `file_key`，不保存本机绝对路径。
9. 幂等 Key 只从请求头 `Idempotency-Key` 读取。
10. 状态流转必须走状态机。
11. 关键状态变化必须写操作日志。
12. Agent 不能无确认执行高风险动作。
13. RAG 不是每次都触发，而是按需触发。

---

## 5. 代码注释要求

所有代码必须写中文注释：

1. 类必须有 `/** */` JavaDoc。
2. public 方法必须有 `/** */` JavaDoc。
3. 核心字段必须有 `//` 注释。
4. 复杂方法内部必须有 `//` 步骤注释。
5. 注释解释业务意图和设计原因，不要只复述代码。
6. Mapper XML 中复杂 SQL 也要有注释。

示例：

```java
/**
 * 售后申请应用服务。
 *
 * 负责售后申请创建的完整用例编排，包括幂等校验、订单归属校验、
 * 售后资格校验、售后主单与明细创建、凭证绑定和操作日志记录。
 */
@Service
public class AfterSalesApplicationService {

    // 售后资格校验服务，统一封装订单状态、数量、金额、重复售后等校验规则
    private final AfterSalesEligibilityService eligibilityService;

    /**
     * 创建售后申请。
     *
     * @param command 售后申请命令
     * @return 售后申请创建结果
     */
    @Transactional(rollbackFor = Exception.class)
    public AfterSalesCreateResult create(AfterSalesCreateCommand command) {
        // 1. 校验幂等 Key，避免用户重复点击导致重复创建售后单
        // 2. 查询订单并校验归属
        // 3. 执行售后资格校验
        // 4. 创建售后主单和明细项
        // 5. 绑定凭证并记录操作日志
        return null;
    }
}
```

---

## 6. 执行前必须先读

每次执行任务前，Claude Code 必须先读取：

```text
README.md
docs/
pom.xml
application.yml
当前模块源码
Mapper XML
已有测试
```

不要基于旧假设生成代码。不要无视已有实现重复造类。不要把文档和代码写成不一致。

---

## 7. 开发顺序

### 7.1 初始化项目

完成：多模块 Maven 或清晰包结构、父 pom、子模块 pom、Spring Boot 启动类、application.yml、application-local.yml、docker-compose.yml、README 初版。

验收：`mvn clean test` 能执行，项目能启动空服务，Docker Compose 能启动 Redis/RabbitMQ/PostgreSQL。

### 7.2 common 模块

实现：Result、PageResult、ErrorCode、BusinessException、GlobalExceptionHandler、IdGenerator、JsonUtils、DateTimeUtils、UserContext。

验收：参数校验错误能统一返回，业务异常能统一返回，Controller 不需要 try-catch。

### 7.3 枚举

实现：UserRole、OrderStatus、PaymentStatus、AfterSalesType、AfterSalesStatus、AfterSalesItemStatus、RefundStatus、ReturnStatus、ExchangeStatus、CompensationType、CompensationStatus、AgentIntent、AgentRiskLevel、KnowledgeDocType、KnowledgeBuildTaskStatus。

要求：每个枚举有 code 和 description，提供 fromCode，不要在业务代码中散落字符串。

### 7.4 数据库脚本

生成：

```text
docs/sql/schema.sql
docs/sql/data.sql
```

schema 必须包含 user_account、product、sku、sku_stock、trade_order、trade_order_item、payment_record、after_sales_order、after_sales_item、after_sales_proof、after_sales_comment、after_sales_operation_log、refund_record、return_record、exchange_record、compensation_record、idempotency_record、agent_trace、agent_tool_call、agent_confirm_action、knowledge_doc、knowledge_chunk、knowledge_build_task、rag_eval_dataset、rag_eval_result。

data.sql 要有普通用户、客服、管理员、商品、SKU、库存、已支付订单、订单项、支付记录、售后政策样例、FAQ 样例、RAG 评估问题样例。

### 7.5 MyBatis 基础设施

为核心表生成 Entity、Mapper、Mapper XML、Repository。

要求：SQL 清晰，更新状态必须带 version 或 expectedStatus，查询详情可以多 SQL 组装，不强行一条巨 SQL，Mapper XML 不写业务流程，只写数据访问。

### 7.6 认证模块

实现：

```http
POST /api/auth/login
POST /api/auth/logout
GET  /api/auth/me
```

要求：Token 存 Redis，拦截器解析用户，支持 USER / CUSTOMER_SERVICE / ADMIN，接口权限可校验。

### 7.7 订单模块

实现：

```http
GET /api/orders
GET /api/orders/{orderNo}
GET /api/orders/{orderNo}/items
```

要求：普通用户只能查自己的订单，客服/管理员可以查全部，订单详情包含订单项和支付记录，返回可售后状态提示。

### 7.8 售后申请模块

实现：

```http
POST /api/after-sales/applications
GET  /api/after-sales
GET  /api/after-sales/{afterSalesNo}
POST /api/after-sales/{afterSalesNo}/cancel
```

必须包含：幂等、订单归属校验、订单状态校验、订单项校验、数量校验、金额校验、重复售后校验、创建主单、创建明细、绑定凭证、更新订单项售后状态、写操作日志。

### 7.9 售后资格校验责任链

实现 OrderExistsChecker、OrderOwnerChecker、OrderStatusChecker、OrderItemChecker、AfterSalesWindowChecker、QuantityChecker、AmountChecker、DuplicateAfterSalesChecker。

要求：每个 Checker 只做一件事，返回结构化失败原因，Agent 资格判断 Skill 复用该服务。

### 7.10 售后状态机

实现 `AfterSalesStateMachine`。

状态：CREATED、PENDING_REVIEW、NEED_MORE_INFO、REJECTED、APPROVED、WAIT_RETURN_SHIPMENT、WAIT_RETURN_RECEIVE、REFUND_PROCESSING、EXCHANGE_PROCESSING、COMPENSATION_PROCESSING、COMPLETED、CANCELLED、FAILED。

要求：非法流转抛异常，所有状态变更通过状态机，单元测试覆盖合法和非法流转。

### 7.11 审核、退款、退货、换货、补偿

实现接口：

```http
POST /api/after-sales/{afterSalesNo}/review/approve
POST /api/after-sales/{afterSalesNo}/review/reject
POST /api/after-sales/{afterSalesNo}/review/need-more-info

POST /api/after-sales/{afterSalesNo}/return/shipment
POST /api/after-sales/{afterSalesNo}/return/receive

POST /api/after-sales/{afterSalesNo}/refund/execute
GET  /api/after-sales/{afterSalesNo}/refund

POST /api/after-sales/{afterSalesNo}/exchange/lock-stock
POST /api/after-sales/{afterSalesNo}/exchange/ship
GET  /api/after-sales/{afterSalesNo}/exchange

POST /api/after-sales/{afterSalesNo}/compensation/grant
GET  /api/after-sales/{afterSalesNo}/compensation
```

要求：高风险接口有权限、幂等、日志、状态机、乐观锁；换货库存锁定使用 Redis；退款和补偿防重复执行；失败记录原因。

### 7.12 Redis 组件

实现 RedisLockService、StockLockService、TokenService、AgentConfirmStateService。

要求：锁有 TTL，解锁校验 owner，库存锁定按 SKU 和售后单维度记录，ConfirmToken 有 TTL，Redis Key 集中管理。

### 7.13 RabbitMQ 组件

实现 RabbitConfig、KnowledgeBuildProducer、KnowledgeBuildConsumer。

要求：配置 exchange、queue、routingKey，配置 Jackson2JsonMessageConverter，消费者支持幂等，失败更新任务状态，不无限重试。

### 7.14 RAG 模块

实现 KnowledgeDocService、KnowledgeChunkService、KnowledgeBuildService、EmbeddingService、VectorStoreService、RagRetrievalService、RagEvaluationService。

要求：售后完成后发布知识构建任务，消费者生成案例知识，切片，调用 Embedding，写入 pgvector，检索 topK，支持 metadata，实现 Recall@3、Recall@5、MRR。

### 7.15 Agent 模块

实现 AgentController、AgentFacade、AgentContextBuilder、AgentIntentRouter、AgentPlanner、SkillRegistry、AgentSkill、AgentRiskGuard、AgentConfirmService、AgentTraceService、SSE Stream Service。

Skills：OrderQuerySkill、AfterSalesEligibilitySkill、AfterSalesDraftSkill、AfterSalesCreateSkill、AfterSalesProgressSkill、RefundEstimateSkill、ExchangeStockCheckSkill、CompensationSuggestionSkill、RagRetrieveSkill。

要求：Agent 按需调用技能，不写固定线性流程；高风险动作生成 confirmToken；Skill 调用业务 Service，不直接操作 Mapper；记录 agent_trace 和 agent_tool_call；SSE 返回 trace/thought/tool/retrieve/delta/confirm/error/done。

### 7.16 Dashboard

实现：

```http
GET /api/dashboard/overview
GET /api/dashboard/after-sales/status-count
GET /api/dashboard/agent/metrics
GET /api/dashboard/rag/metrics
```

### 7.17 测试

生成测试：AfterSalesStateMachineTest、AfterSalesEligibilityServiceTest、IdempotencyServiceTest、StockLockServiceTest、AgentRiskGuardTest、SkillRegistryTest、RagEvaluationServiceTest。

生成 E2E 脚本：`scripts/e2e_return_refund_flow.ps1`、`scripts/e2e_agent_rag_flow.ps1`。

### 7.18 文档

生成 docs：项目总览、架构设计、业务流程、数据库设计、接口设计、状态机、Agent 设计、RAG 设计、Redis/RabbitMQ 设计、本地开发、测试验收、面试说明、编码规范。更新 README。

---

## 8. 总提示词

```text
你现在要实现一个 Java 21 + Spring Boot 3.x 的电商售后智能 Agent 平台，项目名为 after-sales-agent-platform。

开始前必须先阅读当前仓库目录、pom.xml、README、docs、application.yml 和已有源码，避免基于旧数据或错误假设生成代码。

技术选型固定：
- Java 21
- Spring Boot 3.x
- MyBatis，核心 SQL 必须清晰可控
- MySQL 使用本地 127.0.0.1:3306
- Redis、RabbitMQ、PostgreSQL/pgvector 使用 Docker Desktop
- Spring AI 接入 LLM 和 Embedding
- 前端 Vue 3 最后实现

业务约束：
1. 一个售后主单只处理一种售后类型。
2. 用户一次退多个商品时，通过 after_sales_item 支持。
3. 售后主单不要直接存单个 order_item_id。
4. 订单表 paid_amount 是订单快照，支付记录 pay_amount 是资金流水，两者都需要。
5. 换货库存短期锁定使用 Redis，MySQL 保存最终库存事实。
6. 售后主单必须有 version 乐观锁字段。
7. 补偿记录必须有 external_grant_no。
8. 售后凭证保存 file_key，不保存本机绝对路径。
9. 幂等 Key 只从请求头 Idempotency-Key 读取。
10. 状态流转必须通过状态机。
11. 关键状态变化必须写操作日志。
12. Agent 不能无确认执行高风险动作。
13. RAG 按需触发，不要每次都强制调用。

Agent 约束：
- Agent 不是固定线性流程。
- 使用 SkillRegistry 管理能力。
- Skill 调用业务 Service，不直接操作 Mapper。
- 高风险动作生成 confirmToken。
- Agent 调用记录 traceId、工具调用、RAG 命中、最终回答。
- SSE 返回 trace、thought、tool、retrieve、delta、confirm、error、done。

RAG 约束：
- 售后完成后通过 RabbitMQ 异步构建知识。
- 知识来源包括政策、FAQ、历史案例、客服手册。
- 使用 PostgreSQL/pgvector 存储向量。
- 实现 Recall@3、Recall@5、MRR。
- local/dev 可以 MySQL fallback，但必须明确日志说明不是长期主路径。

代码规范：
- 类、public 方法必须有中文 JavaDoc。
- 核心字段和复杂逻辑内部必须有中文注释。
- Controller 不写复杂业务。
- Service 做用例编排。
- Domain Service 做规则。
- Mapper 做数据访问，SQL 清晰可控。

请按文档中的开发顺序逐步实现。每完成一部分，输出：
1. 新增/修改文件
2. 关键实现说明
3. 如何运行
4. 如何测试
5. 仍未完成的内容

不要只生成伪代码，不要只生成空方法，不要忽略测试，不要让文档和代码不一致。
```
